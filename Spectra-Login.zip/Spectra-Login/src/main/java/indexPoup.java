public class indexPoup {
    public static void main(String[] args) {

        ClasseAcessoPoup caixasMensangens = new ClasseAcessoPoup();

        String opcaoDigitada = "";

        caixasMensangens.msgBemVindo(opcaoDigitada);
    }
}
